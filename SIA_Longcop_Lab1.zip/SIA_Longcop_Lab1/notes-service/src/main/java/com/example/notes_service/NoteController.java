package com.example.notes_service;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    private final List<Note> notes = new ArrayList<>();
    private final AtomicLong counter = new AtomicLong();

    @GetMapping
    public List<Note> getNotes() {
        return notes;
    }

    @PostMapping
    public Note createNote(@RequestBody Note note) {
        note.setId(counter.incrementAndGet());
        notes.add(note);
        return note;
    }

    @GetMapping("/{id}")
    public Note getNoteById(@PathVariable Long id) {
        return notes.stream()
                .filter(note -> note.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @PutMapping("/{id}")
    public Note updateNote(@PathVariable Long id, @RequestBody Note updatedNote) {
        for (Note note : notes) {
            if (note.getId().equals(id)) {
                note.setContent(updatedNote.getContent());
                return note;
            }
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void deleteNote(@PathVariable Long id) {
        notes.removeIf(note -> note.getId().equals(id));
    }
}